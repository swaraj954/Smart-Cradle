FOLLOW THE STEPS:

1) Inside Actual Dataset folder, inside Train_audio folder, run the get_dataset python file.
This will fill this location with all the required Dataset. Files with T prefix means it is a file belonging to true class, False otherwise

2)Run Train_Model2, this will train the model on the generated dataset.This will create a .SAV file that contains the model